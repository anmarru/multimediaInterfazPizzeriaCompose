package com.andrea.compose_pizzeria.data

enum class SIZE {GRANDE, MEDIANO, PEQUEÑO }