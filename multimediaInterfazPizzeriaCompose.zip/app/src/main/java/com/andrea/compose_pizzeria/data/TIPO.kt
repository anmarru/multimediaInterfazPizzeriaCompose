package com.andrea.compose_pizzeria.data

enum class TIPO {PIZZA, PASTA, BEBIDA}