package com.andrea.compose_pizzeria.data

enum class ESTADO_PEDIDO {
    PENDIENTE , TERMINADO, ENTREGADO, CANCELADO
}
