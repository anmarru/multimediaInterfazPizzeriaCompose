package com.andrea.compose_pizzeria.data

data class BebidaDTO (
    val id: Int,
    val nombre: String,
    val precio: Float,
    val size: SIZE
)